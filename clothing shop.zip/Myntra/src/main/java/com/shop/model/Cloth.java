package com.shop.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "myntra_cloth")
public class Cloth {
	
	@Id
	@GeneratedValue
	private int id;
	
	private String clothName;
	
	private String categoy;
	
	private String description;
	
	private int availQuantity;
	
	private String clothType;
	
	private int price;
	
	private int size;

	public Cloth() {
		super();
	}

	public Cloth(String clothName, String categoy, String description, int availQuantity, String clothType, int price) {
		super();
		this.clothName = clothName;
		this.categoy = categoy;
		this.description = description;
		this.availQuantity = availQuantity;
		this.clothType = clothType;
		this.price = price;
	}

	public Cloth(String clothName, String categoy, String description, int availQuantity, String clothType, int price,
			int size) {
		super();
		this.clothName = clothName;
		this.categoy = categoy;
		this.description = description;
		this.availQuantity = availQuantity;
		this.clothType = clothType;
		this.price = price;
		this.size = size;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getClothName() {
		return clothName;
	}

	public void setClothName(String clothName) {
		this.clothName = clothName;
	}

	public String getCategoy() {
		return categoy;
	}

	public void setCategoy(String categoy) {
		this.categoy = categoy;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getAvailQuantity() {
		return availQuantity;
	}

	public void setAvailQuantity(int availQuantity) {
		this.availQuantity = availQuantity;
	}

	public String getClothType() {
		return clothType;
	}

	public void setClothType(String clothType) {
		this.clothType = clothType;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
	


}

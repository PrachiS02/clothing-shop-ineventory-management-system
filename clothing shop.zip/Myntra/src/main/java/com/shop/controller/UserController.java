package com.shop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.shop.model.Cloth;
import com.shop.service.ClothService;

@Controller
public class UserController {
	
	@Autowired
	private ClothService clothServ;
	
	/*
	 * @Autowired private UserService userSer;
	 * 
	 * @Autowired private CartService cservice;
	 */

	@GetMapping("/")
	public String welcomeP() 
	{
		return "welcome";
	}
	
	@GetMapping("/welcome_admin")
	public String welcomeAdmin() 
	{
		return "welcomeAdmin";
	}
	
	@GetMapping("/welcome_user")
	public ModelAndView welcomeUser() 
	{
		List<Cloth> allproduct = clothServ.getAllProduct();
		ModelAndView mv = new ModelAndView("bypass_user");
		
		mv.addObject("ListOfProduct",allproduct);
		
		return mv;
	}
	
	@GetMapping("/bypass_adminn")
	public String adminProduct() 
	{
		return "bypass_admin";
	}
	
	@GetMapping("/save")
	public String adminAddProduct(@RequestParam ("clothName") String clName,@RequestParam ("price") int pri,@RequestParam ("availQuantity") int quan,
			@RequestParam ("categoy") String cat,@RequestParam ("clothType") String type ,@RequestParam ("description") String desc ) 
	{
		if(clName!=null && pri!=0 && quan!=0 && type!=null && cat!=null && cat!=null) {
				Cloth cl = new Cloth();
				cl.setAvailQuantity(quan);
				cl.setClothName(clName);
				cl.setPrice(pri);
				cl.setCategoy(cat);
				cl.setClothType(type);
				cl.setDescription(desc);
				boolean check =clothServ.addNewProduct(cl);
				if(check) {
					return "suc";
				}else {
					return "problemAdmin";
				}
		} else {
			return "problemAdmin";
		}
	}
	
	

}

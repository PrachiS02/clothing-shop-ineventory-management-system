package com.shop.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shop.model.Cloth;

@Repository
@Transactional
public class ClothRepository{

	@Autowired
	private SessionFactory sf;
	
	public boolean addProduct(Cloth cl) {
		if(cl!=null) {
			sf.getCurrentSession().save(cl);
			return true;
		} else {
			return false;
		}
	}

	public List<Cloth> getAllProducts() {
		
		Query<Cloth> q = sf.getCurrentSession().createQuery("from Cloth");
		
		List <Cloth> list = q.list();
	
		return list;
		
	}
}

package com.shop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shop.model.Cloth;
import com.shop.repository.ClothRepository;


@Service
public class ClothServiceImpl implements ClothService{
	
	@Autowired
	private ClothRepository clothRepo;

	@Override
	public boolean addNewProduct(Cloth cl) {
		boolean check =clothRepo.addProduct(cl);
		return check;
	}

	@Override
	public List<Cloth> getAllProduct() {
		List<Cloth> all = clothRepo.getAllProducts();
		return all;
	}

}
